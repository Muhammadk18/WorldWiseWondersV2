<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="keywords" content="WorldWiseWonders"/>
    <meta
            name="description"
            content="Educational platform for BanglaDesh Community"
    />
    <!-- SITE TITLE -->
    <title>WorldWiseWonders</title>
    <link rel="stylesheet" href="./style/navbar.css"/>
    <link rel="stylesheet" href="./style/cityQuiz.css"/>
    <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
    />
    <link rel="icon" type="image/x-icon" href="./Images/favicon-32x32.png"/>
</head>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        var links = document.querySelectorAll(".nav-links a");
        links.forEach(function (link) {
            link.addEventListener("click", function () {
                document.getElementById("nav-check").checked = false; // Uncheck the checkbox when a link is clicked
            });
        });
    });
</script>

<script>
    window.onscroll = function () {
        scrollFunction();
    };

    function scrollFunction() {
        if (
            document.body.scrollTop > 20 ||
            document.documentElement.scrollTop > 20
        ) {
            document.getElementById("goToTopBtn").style.display = "block";
        } else {
            document.getElementById("goToTopBtn").style.display = "none";
        }
    }

    // Smooth scroll to the top
    function goToTop() {
        const scrollToTop = () => {
            const c = document.documentElement.scrollTop || document.body.scrollTop;
            if (c > 0) {
                window.requestAnimationFrame(scrollToTop);
                window.scrollTo(0, c - c / 8);
            }
        };
        scrollToTop();
    }
</script>

<body>
<div class="nav">
    <input type="checkbox" id="nav-check"/>
    <div class="nav-header">
        <div class="nav-title">
            <img class="logo" src="./Images/Greater_Bangladesh_Logo.png"/>
        </div>
    </div>
    <div class="nav-btn">
        <label for="nav-check">
            <span></span>
            <span></span>
            <span></span>
        </label>
    </div>

    <div class="nav-links">
        <a href="./index.html">Home </a>
        <a href="./index.html">Cities</a>
        <a href="./leaderboard.php" style="color: black">Leaderboard</a>
    </div>
</div>

<section class="mainQuizSection" id="home" style="margin-top: 1rem">
    <div class="leaderboard-container">
        <h2>Leaderboard</h2>
        <table class="leaderboard">
            <tbody>
            <tr>
                <th>Name</th>
                <th>Score</th>
            </tr>

            <?php
            include_once('includes/config.php');
            $ret = mysqli_query($con, "select * from quiz");
            $cnt = 1;
            while ($row = mysqli_fetch_array($ret)) {
                ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['score']; ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</section>

<script>
    document.getElementById("currentYear").innerText =
        new Date().getFullYear();
</script>
<button onclick="goToTop()" id="goToTopBtn" title="Go to top">
    <svg
            class=""
            style="transform: rotate(180deg); fill: white"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            version="1.1"
            x="0px"
            y="0px"
            width="18px"
            height="16.043px"
            viewBox="57 35.171 26 16.043"
            enable-background="new 57 35.171 26 16.043"
            xml:space="preserve"
    >
        <path
                d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z"
        ></path>
      </svg>
</button>
</body>
</html>
