<?php
include_once('includes/config.php');
$name = $_POST['name'];
$score = $_POST['score'];
$questions = $_POST['questions'];

$msg = mysqli_query($con, "insert into quiz(name,score,questions) values('$name','$score','$questions')");

if ($msg) {
    echo 'success';
} else {
    echo 'error';
}
